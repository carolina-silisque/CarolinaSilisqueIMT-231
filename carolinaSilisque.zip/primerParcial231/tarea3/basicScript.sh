#!/bin/bash 
echo "!bienvenido , por favor ingresa tu nombre:"
read $nombre
echo 'saludos,' cat 
 
tree

script finalizado 

